<?php
require_once 'DBConnection.php';
require_once 'Usuario.php';
class UsuarioCrud
{
    //SEMPRE QUE A CLASSE FOR INSTANCIADA, JA FAZ A CONEXÃO E GUARDA
    private $conexao;

    public function __construct()
    {
        $this->conexao = DBConnection::getConexao();
    }
    //RETORNA VERDADEIRO OU FALSA

    public function LoginUsuario(Usuario $user){
        $sql = $this->conexao->prepare("SELECT nome,senha FROM Usuario WHERE nome = '{$user->getNome()}' AND senha = '{$user->getSenha()}'");
        $sql->execute();
        $resultado = $sql->rowCount();
        try{
            if ($resultado == 1){
                session_start();
                $_SESSION['nome'] = $user->getNome();
                //echo "Deu certo ".$user->getNome();
                header("Location: ../Views/PaginaPrincipal/index.phtml");
            }else{
                header("Location:../Views/Formularios/login.php?erro=1");
                $nome = $user->getNome();
                echo $nome;
            }
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function logout(){
        session_start();
        session_destroy();
    }


    public function getUsuario($id)
    {
        //RETORNA UMA CATEGORIA, DADO UM ID

        //FAZER A CONSULTA
        $sql = 'select * from usuarios where id_usuario='.$id;
        $resultado = $this->conexao->query($sql);

        //FETCH - TRANSFORMA O RESULTADO EM UM ARRAY ASSOCIATIVO
        $usuario = $resultado->fetch(PDO::FETCH_ASSOC);

        //CRIAR OBJETO DO TIPO CATEGORIA - USANDO OS VALORES DA CONSULTA
        $objetoUsuario = new Usuario($usuario['id_usuario'], $usuario['nome'], $usuario['senha'], $usuario['email'], $usuario['telefone'], $usuario['cpf'], $usuario['endereco']);

        //RETORNAR UM OBJETO CATEGORIA COM OS VALORES
        return $objetoUsuario;

    }


    public function getUsuarios()
    {
        $sql = "SELECT * FROM usuarios";

        $resultado = $this->conexao->query($sql);

        $usuarios = $resultado->fetchAll(PDO::FETCH_ASSOC);

        foreach ($usuarios as $usuario) {
            $nome = $usuario['nome'];
            $senha = $usuario['senha'];
            $email = $usuario['email'];
            $telefone = $usuario['telefone'];
            $cpf = $usuario['cpf'];
            $endereco = $usuario['endereco'];

            $obj = new Usuario($nome, $senha, $email, $telefone, $cpf, $endereco);
            $listaUsuario[] = $obj;
        }
        return $listaUsuario;
    }

    public function updateUsuario(Usuario $user){

        $this->conexao = DBConnection::getConexao();

        $sql = "UPDATE usuarios SET nome = '$user->nome', senha = $user->senha, email = $user->email, telefone = '$user->telefone', cpf = '$user->cpf', endereco = '$user->endereco'
        WHERE id_usuario = $user->id";

        try {//TENTA EXECUTAR A INSTRUCAO

            $this->conexao->exec($sql);
        } catch (PDOException $e) {//EM CASO DE ERRO, CAPTURA A MENSAGEM
            return $e->getMessage();
        }
    }

    public function insertUsuario(Usuario $user)
    {

        //EFETUA A CONEXAO
        $this->conexao = DBConnection::getConexao();
        //MONTA O TEXTO DA INSTRUÇÂO SQL
        $sql = "insert into usuarios (nome, senha,endereco,telefone,email,cpf) 
        values ('{$user->getNome()}','{$user->getSenha()}','{$user->getEndereco()}','{$user->getTelefone()}','{$user->getEmail()}','{$user->getCpf()}')";

        try {//TENTA EXECUTAR A INSTRUCAO

            $this->conexao->exec($sql);
        } catch (PDOException $e) {//EM CASO DE ERRO, CAPTURA A MENSAGEM
            return $e->getMessage();
        }
    }


}