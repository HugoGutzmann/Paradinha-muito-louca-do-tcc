<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 26/04/18
 * Time: 16:40
 */

class ControlerLocal
{

}